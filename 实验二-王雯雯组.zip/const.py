#coding = utf-8
BASE_URL="http://httpbin.org/"
IP_URL="/ip"
LOCAL_IP="110.188.59.201"
POST_TEST_URL="/post"
